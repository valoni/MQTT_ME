﻿using System;
using System.Collections;
using System.Text;
using System.Diagnostics;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using GHIElectronics.TinyCLR.Devices.Network;
using GHIElectronics.TinyCLR.Networking.Mqtt;
using GHIElectronics.TinyCLR.Devices.Gpio;
using GHIElectronics.TinyCLR.Devices.Spi;
using GHIElectronics.TinyCLR.Pins;
using System.Security.Cryptography.X509Certificates;
using GHIElectronics.TinyCLR.Native;

/**/
namespace TinyCLRMqtt
{
    class Program
    {

        private static Mqtt client;

        private static bool linkReady = false;
        private static NetworkController networkController;

        static void Main()
        {
            Debug.WriteLine("Setup WiFi");
            SetupWifiAtwinc1510_MicroBus(SC20100.SpiBus.Spi3, SC20100.GpioPin.PA6, SC20100.GpioPin.PD14, SC20100.GpioPin.PA8, SC20100.GpioPin.PD15, SC20100.GpioPin.Id);
          
            //Debug.WriteLine("Setup Ethernet");
            //SetupEnc28_MicroBus(SC20100.SpiBus.Spi3, SC20100.GpioPin.PD14, SC20100.GpioPin.PA8, SC20100.GpioPin.PD15, SC20100.GpioPin.Id);
            
            Thread.Sleep(50);

            Debug.WriteLine("Setup Date and Time from Internet");
            Debug.WriteLine("===================================");

            while
            ((DateTime.UtcNow.ToString("yyyy.MM.dd") == "1900.01.01") || (DateTime.UtcNow.ToString("yyyy.MM.dd") == "2017.01.01"))
            {
                SystemTime.SetTime(GetNetworkTime(2));
                Thread.Sleep(15000);
                // Debug.WriteLine("Try again after 15 sec");
            }

            Debug.WriteLine("Set Proper Time now is :" + DateTime.UtcNow.ToString("yyyy.MM.dd HH:mm:ss"));
            Debug.WriteLine("===================================");


            var caCertificate = new X509Certificate(CaCertificate());
            var clCertificate = new X509Certificate(ClCertificate());

            var mqttHost = "val.itdbcks.net";

            var mqttPort = 8883;//8883 
            var deviceId = "tiny_clr_device_001";

            string username = "Valon";
            string password = "Test";

            string topic1 = "tinyclr/temp";
            string topic2 = "tinyclr/humidity";


            string subtopic1 = "home/temperature";
            string subtopic2 = "home/humidity";

            var clientSetting = new MqttClientSetting
            {
                BrokerName = mqttHost,
                BrokerPort = mqttPort,
                ClientCertificate = clCertificate,
                CaCertificate = caCertificate,
                SslProtocol = System.Security.Authentication.SslProtocols.Tls12
            };

            try
            {
                client = new Mqtt(clientSetting);
            }
            catch (Exception e)
            {
                Debug.WriteLine("Failure one");
                Debug.WriteLine(e.Message.ToString());
            }

            client.PublishReceivedChanged += Client_PublishReceivedChanged;


            client.SubscribedChanged += (a, b) => {
                Debug.WriteLine("Subscribed");
            };



            var connectSetting = new MqttConnectionSetting
            {
                ClientId = deviceId,
                UserName = username,
                Password = password,
                KeepAliveTimeout = 60,
                LastWillQos = QoSLevel.MostOnce,
                CleanSession = true
            };

            var returnCode = client.Connect(connectSetting);

            var packetId = 1;

            // Subscribe to a topic before start with publish ...
            client.Subscribe(new string[] { subtopic1, subtopic2 }, new QoSLevel[] { QoSLevel.MostOnce, QoSLevel.MostOnce }, (ushort)packetId++);

            client.SubscribedChanged += Client_SubscribedChanged;

            while (true)
            {
                Debug.WriteLine(DateTime.UtcNow.ToString("------------------------------"));
                Debug.WriteLine(DateTime.UtcNow.ToString(">> yyyy.MM.dd HH:mm:ss.fff"));

                //Publish a topic
                client.Publish(topic1, GetRandomTemperature(), QoSLevel.MostOnce, false, (ushort)packetId);
                packetId++;
                //Publish a topic
                client.Publish(topic2, GetRandomHumidity(), QoSLevel.MostOnce, false, (ushort)(packetId+1));
                packetId++;

                //client.PublishedChanged += (a, b, c) =>
                //{
                //    Debug.WriteLine("Published " + a.ToString());
                //};

                Debug.WriteLine("Wait next 15 sec");
                Thread.Sleep(15000);
            }

        }

        private static void Client_SubscribedChanged(object sender, MqttPacket packet)
        {
            if(packet.Data!=null)
            { 
            Debug.WriteLine("SubscribeChanged");
            string payload = UTF8Encoding.UTF8.GetString(packet.Data);
            Debug.WriteLine("subscribe id" + packet.PacketId); 
            Debug.WriteLine("Payload : " + payload);
            }
            else
            {
                Debug.WriteLine("SubscribeChanged");
                Debug.WriteLine("Nothing to received");
            }
        }

        private static void Client_PublishReceivedChanged(object sender, MqttPacket packet)
        {
            Debug.WriteLine("PublishReceivedChanged");
            string payload = UTF8Encoding.UTF8.GetString(packet.Data);
            //Debug.WriteLine("subscribe id" + packet.PacketId); 
            Debug.WriteLine("Payload : " + payload);
        }

        //WIFI SETUP
        static void SetupWifiAtwinc1510_MicroBus(string _SpiApiName,int _en, int _cs, int _intPin, int _rst, string _GpioApiName)
        {
            var enablePin = GpioController.GetDefault().OpenPin(_en);
            enablePin.SetDriveMode(GpioPinDriveMode.Output);
            enablePin.Write(GpioPinValue.High);

            SpiNetworkCommunicationInterfaceSettings netInterfaceSettings =
                new SpiNetworkCommunicationInterfaceSettings();

            var cs = GpioController.GetDefault().OpenPin(_cs);

            var settings = new SpiConnectionSettings()
            {
                ChipSelectLine = cs,
                ClockFrequency = 4000000,
                Mode = SpiMode.Mode0,
                ChipSelectType = SpiChipSelectType.Gpio,
                ChipSelectHoldTime = TimeSpan.FromTicks(10),
                ChipSelectSetupTime = TimeSpan.FromTicks(10)
            };


            netInterfaceSettings.SpiApiName = _SpiApiName;
            netInterfaceSettings.GpioApiName = _GpioApiName;

            netInterfaceSettings.SpiSettings = settings;
            netInterfaceSettings.InterruptPin = GpioController.GetDefault().OpenPin(_intPin);

            netInterfaceSettings.InterruptEdge = GpioPinEdge.FallingEdge;
            netInterfaceSettings.InterruptDriveMode = GpioPinDriveMode.InputPullUp;
            netInterfaceSettings.ResetPin = GpioController.GetDefault().OpenPin(_rst);
            netInterfaceSettings.ResetActiveState = GpioPinValue.Low;

            var networkController = NetworkController.FromName("GHIElectronics.TinyCLR.NativeApis.ATWINC15xx.NetworkController");

            WiFiNetworkInterfaceSettings wifiSettings = new WiFiNetworkInterfaceSettings()
            {
                Ssid = "valoninet",
                Password = "valoni1234567",
            };

            wifiSettings.Address = new IPAddress(new byte[] { 192, 168, 2, 122 });
            wifiSettings.SubnetMask = new IPAddress(new byte[] { 255, 255, 255, 0 });
            wifiSettings.GatewayAddress = new IPAddress(new byte[] { 192, 168, 2, 1 });
            wifiSettings.DnsAddresses = new IPAddress[] { new IPAddress(new byte[]{ 8, 8, 8, 8 }), new IPAddress(new byte[] { 8, 8, 8, 4 }) };

            wifiSettings.MacAddress = new byte[] { 0x00, 0x4, 0x00, 0x00, 0x00, 0x00 };
            wifiSettings.IsDhcpEnabled = true;
            wifiSettings.IsDynamicDnsEnabled = true;
            wifiSettings.TlsEntropy = new byte[] { 0, 1, 2, 3 };

            networkController.SetInterfaceSettings(wifiSettings);
            networkController.SetCommunicationInterfaceSettings(netInterfaceSettings);
            networkController.SetAsDefaultController();

            networkController.NetworkAddressChanged += NetworkController_NetworkAddressChanged;

            networkController.NetworkLinkConnectedChanged +=
                NetworkController_NetworkLinkConnectedChanged;

            networkController.Enable();

            while (linkReady == false) ;
            Debug.WriteLine("===================================");
            Debug.WriteLine("Network is ready to use:");
            Debug.WriteLine("===================================");
            Debug.WriteLine(networkController.GetIPProperties().Address.ToString());
            Debug.WriteLine(networkController.GetIPProperties().SubnetMask.ToString());
            Debug.WriteLine(networkController.GetIPProperties().GatewayAddress.ToString());
            Debug.WriteLine(networkController.GetIPProperties().DnsAddresses[1].ToString());
            Debug.WriteLine("===================================");
        }


        //ETHERNET SETUP
        static void SetupEnc28_MicroBus(string _SpiApiName, int _cs, int _intPin, int _rst, string _GpioApiName)
        {
            networkController = NetworkController.FromName("GHIElectronics.TinyCLR.NativeApis.ENC28J60.NetworkController");

            var networkInterfaceSetting = new EthernetNetworkInterfaceSettings();
            var networkCommunicationInterfaceSettings = new SpiNetworkCommunicationInterfaceSettings();

            networkCommunicationInterfaceSettings.SpiApiName = _SpiApiName;
            networkCommunicationInterfaceSettings.GpioApiName = _GpioApiName;

            var cs = GpioController.GetDefault().OpenPin(_cs);

            var settings = new SpiConnectionSettings()
            {
                ChipSelectLine = cs,
                ClockFrequency = 4000000,
                Mode = SpiMode.Mode0,
                ChipSelectType = SpiChipSelectType.Gpio,
                ChipSelectHoldTime = TimeSpan.FromTicks(10),
                ChipSelectSetupTime = TimeSpan.FromTicks(10)
            };

            networkCommunicationInterfaceSettings.SpiSettings = settings;
            networkCommunicationInterfaceSettings.InterruptPin = GpioController.GetDefault().OpenPin(_intPin);
            networkCommunicationInterfaceSettings.InterruptEdge = GpioPinEdge.FallingEdge;
            networkCommunicationInterfaceSettings.InterruptDriveMode = GpioPinDriveMode.InputPullUp;
            networkCommunicationInterfaceSettings.ResetPin = GpioController.GetDefault().OpenPin(_rst);
            networkCommunicationInterfaceSettings.ResetActiveState = GpioPinValue.Low;

            networkInterfaceSetting.Address = new IPAddress(new byte[] { 192, 168, 2, 122 });
            networkInterfaceSetting.SubnetMask = new IPAddress(new byte[] { 255, 255, 255, 0 });
            networkInterfaceSetting.GatewayAddress = new IPAddress(new byte[] { 192, 168, 2, 1 });
            networkInterfaceSetting.DnsAddresses = new IPAddress[] { new IPAddress(new byte[] { 8, 8, 8, 8 }), new IPAddress(new byte[] { 75, 75, 75, 76 }) };

            networkInterfaceSetting.MacAddress = new byte[] { 0x00, 0x4, 0x00, 0x00, 0x00, 0x00 };
            networkInterfaceSetting.IsDhcpEnabled = true;
            networkInterfaceSetting.IsDynamicDnsEnabled = true;

            networkInterfaceSetting.TlsEntropy = new byte[] { 0, 1, 2, 3 };

            networkController.SetInterfaceSettings(networkInterfaceSetting);
            networkController.SetCommunicationInterfaceSettings(networkCommunicationInterfaceSettings);

            networkController.SetAsDefaultController();

            networkController.NetworkAddressChanged += NetworkController_NetworkAddressChanged; ;
            networkController.NetworkLinkConnectedChanged += NetworkController_NetworkLinkConnectedChanged; ;

            networkController.Enable();

            while (linkReady == false) ;
            Debug.WriteLine("===================================");
            Debug.WriteLine("Network is ready to use:");
            Debug.WriteLine("===================================");
            Debug.WriteLine(networkController.GetIPProperties().Address.ToString());
            Debug.WriteLine(networkController.GetIPProperties().SubnetMask.ToString());
            Debug.WriteLine(networkController.GetIPProperties().GatewayAddress.ToString());
            Debug.WriteLine(networkController.GetIPProperties().DnsAddresses[1].ToString());
            Debug.WriteLine("===================================");

        }

        private static void NetworkController_NetworkLinkConnectedChanged(NetworkController sender, NetworkLinkConnectedChangedEventArgs e)
        {
            //throw new NotImplementedException();
        }

        private static void NetworkController_NetworkAddressChanged(NetworkController sender, NetworkAddressChangedEventArgs e)
        {
            var ipProperties = sender.GetIPProperties();
            var address = ipProperties.Address.GetAddressBytes();

            linkReady = address[0] != 0;
        }

        public static DateTime GetNetworkTime(int CorrectLocalTime = 0)
        {
            const string ntpServer = "pool.ntp.org";
            var ntpData = new byte[48];
            ntpData[0] = 0x1B; //LeapIndicator = 0 (no warning), VersionNum = 3 (IPv4 only), Mode = 3 (Client Mode)

            var addresses = Dns.GetHostEntry(ntpServer).AddressList;
            var ipEndPoint = new IPEndPoint(addresses[0], 123);
            var socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            socket.Connect(ipEndPoint);

            Thread.Sleep(10); // added to support TinyCLR OS too

            //addedd time out for TinyCLR OS ..
            socket.ReceiveTimeout = 5000;
            socket.SendTimeout = 5000;

            socket.Send(ntpData);

            socket.Receive(ntpData);

            socket.Close();

            ulong intPart = (ulong)ntpData[40] << 24 | (ulong)ntpData[41] << 16 | (ulong)ntpData[42] << 8 | (ulong)ntpData[43];
            ulong fractPart = (ulong)ntpData[44] << 24 | (ulong)ntpData[45] << 16 | (ulong)ntpData[46] << 8 | (ulong)ntpData[47];

            var milliseconds = (intPart * 1000) + ((fractPart * 1000) / 0x100000000L);
            var networkDateTime = (new DateTime(1900, 1, 1)).AddMilliseconds((long)milliseconds);

            return networkDateTime.AddHours(CorrectLocalTime);
        }

        //simulate random Temperature ..
        private static byte[] GetRandomTemperature()
        {
            // generate random value
            Random randomProvider = new Random();
            var randomTemperature = randomProvider.NextDouble() * 10;

            // convert to string formatted NN.NN
            var temperatureAsString = randomTemperature.ToString("N2");

            Debug.WriteLine($"Temperature: {temperatureAsString}");

            return Encoding.UTF8.GetBytes(temperatureAsString);
        }

        private static byte[] GetRandomHumidity()
        {
            // generate random value
            Random randomProvider = new Random();
            var randomTemperature = randomProvider.NextDouble() * 100;

            // convert to string formatted NN.NN
            var temperatureAsString = randomTemperature.ToString("N2");

            Debug.WriteLine($"Humidity: {temperatureAsString}");

            return Encoding.UTF8.GetBytes(temperatureAsString);
        }

        static byte[] CaCertificate()
        {
            // val MQTTNET test server with CA certificate from http://val.itdbcks.net/
            // X509 
            string GetCertificate =
    @"-----BEGIN CERTIFICATE-----
MIIDHTCCAgWgAwIBAgIUR4nFISPQlCg0mLklY5EncQRtSPkwDQYJKoZIhvcNAQEL
BQAwHjELMAkGA1UEBhMCWEsxDzANBgNVBAMMBlZNSC1DQTAeFw0yMDA5MDIxMjIw
MTJaFw0zMDA4MzExMjIwMTJaMB4xCzAJBgNVBAYTAlhLMQ8wDQYDVQQDDAZWTUgt
Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDG73m/Qr81frs7GosP
M73qdN2QiyRIRK8F+InX3utZJ31swR0nn2R2BreQ2yhCuviUP/084TB/nQ2Ah/A5
/VzCNecGgOM31Je/9Km+v6KO1l1l22pczLHcpUh2ZpcHLnwyjEXpoLCi6uKnkYwl
WuJCpjYkwli1jtMutjBiMfJRAneMhf0rFYM5qxlQMy2l/r9Vwd/PpMBWLeb90Hd3
GsobsnSGnVhjj1OwoFn2BRUGKkG57qBDPKm1M3MkyklZsc4MJpDEqbzQslhDkQoo
Q87COutqkLgY61W2dAbQ0LpyerwAjNRimfd5kVSg6xe4XzCaVNJ/Tm319KMrxLs2
Iw8fAgMBAAGjUzBRMB0GA1UdDgQWBBT8pfHf997WUfvdxJhRoyuJrolUBzAfBgNV
HSMEGDAWgBT8pfHf997WUfvdxJhRoyuJrolUBzAPBgNVHRMBAf8EBTADAQH/MA0G
CSqGSIb3DQEBCwUAA4IBAQAJ51ekYwAzMB50izpoDZr39cEMqBeCii4lfAVpHvpw
fm82JgwdtaHfcF5B+5lqY3NCKUHBYBk+EHGT8dDLxirCXSA7brslr3SL4aaZ9BrU
Y0ZA4Czk0FrrLDCawBrKZ2fymZ6n+LkkwEVkUpOM3sxVW1KTTt8Tk+cD3nDqBV2R
0RCfiH+MffmgmzGsV2aKrzPJdltGOCgEW9ErsrUbTziTJ4U+yFAvZxZPQAaML2Xf
MvBRE5HHA0MpH93xyhAFQ811gGcJkmwQA8lEoX11gIV4PCssj4mbB7IQYnvK0UWZ
WsEB4WPdj/Kp25IthQz5tERqei50Km5bLDZrXQqPuE++
-----END CERTIFICATE-----";

            return UTF8Encoding.UTF8.GetBytes(GetCertificate);
        }

        static byte[] ClCertificate()
        {
            // val MQTTNet test server Client certificate from http://val.itdbcks.net/
            // X509 
            string GetClCertificate =
    @"-----BEGIN CERTIFICATE-----
MIIDmDCCAoCgAwIBAgIUMRiW7q1lCSYkKiL6lxwlTnZ7zBQwDQYJKoZIhvcNAQEL
BQAwHjELMAkGA1UEBhMCWEsxDzANBgNVBAMMBlZNSC1DQTAeFw0yMDA5MDQwNTU0
NDNaFw0yODEyMTUwNTU0NDNaMFUxCzAJBgNVBAYTAlhLMQswCQYDVQQIDAJYSzES
MBAGA1UEBwwJUHJpc2h0aW5hMQswCQYDVQQKDAJWSDEYMBYGA1UEAwwPdmFsLml0
ZGJja3MubmV0MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA633l77dp
9aNm4gB8ftdkJ28jwH1GZ0s4toQYAV81R5maM9OIF8r3uQoaRurJWjK2pdKNvhbk
IQdbzWZAKewtVhythLs5+rjSACXgIDiiHOc63+c6Mv8pXmrIca4y7XkBEIVKvhrM
QpDPqzlmpd3SEmXmv4l3ogM1keckBNmXefCWuRWztoPqHXBV93GgexJMOFQJxjxL
oL45nW8yNpvDyIHylKE2tAYP6cnin2WF6RTAZUNYlQZZdUwcXg0kXcoKvl2zADW/
FbtazeOdNI79FSduQiivzwqKhf6TS8b9f+2LDDgXrqb/EBz7zmxv8w6bG7+NO9jG
xUziMctsi96qOQIDAQABo4GWMIGTMB8GA1UdIwQYMBaAFPyl8d/33tZR+93EmFGj
K4muiVQHMAkGA1UdEwQCMAAwCwYDVR0PBAQDAgTwMFgGA1UdEQRRME+CD3ZhbC5p
dGRiY2tzLm5ldIIPdmFsb25pLmRkbnMubmV0gglsb2NhbGhvc3SCDTE5Mi4xNjgu
Mi4xMTCCBm1lcml0YYIJMTI3LjAuMC4xMA0GCSqGSIb3DQEBCwUAA4IBAQAph82r
TXSpDEakU3IytuXInaiow9RvKp5nR0W4/WR8cD1eOaYcDypXktM+xh9uSE+KahMM
/khVUUSoK9X9ZqGoOBRmR4ij+hPrQjm9NkCq8U9vadcOgwwlo79GHN/inkzLBU00
E7hfqBjUxvXI7Zpv/4LejoHWazq517nU8C9KvgB/p7a2XNQaBXaf6HrFQ2Mds1oZ
RZaXlb0hxiDkYex1JtvL6w0fE1efhzYdC1a1LlRLeRKpUaaISognlhYLHmU0zoEJ
IGSs6OYZAbIZa/xpRBfySEIXcK3n2MFCh3RsWCxWXB1fnXyzdCIapFOTw2LNBmik
MhNkOLiEBVHPUI8Z
-----END CERTIFICATE-----";

            return UTF8Encoding.UTF8.GetBytes(GetClCertificate);
        }
    }
}

