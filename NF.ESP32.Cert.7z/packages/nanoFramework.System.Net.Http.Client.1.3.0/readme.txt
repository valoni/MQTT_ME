                           _____                                            _    
   _ __   __ _ _ __   ___ |  ___| __ __ _ _ __ ___   _____      _____  _ __| | __
  | '_ \ / _` | '_ \ / _ \| |_ | '__/ _` | '_ ` _ \ / _ \ \ /\ / / _ \| '__| |/ /
  | | | | (_| | | | | (_) |  _|| | | (_| | | | | | |  __/\ V  V / (_) | |  |   < 
  |_| |_|\__,_|_| |_|\___/|_|  |_|  \__,_|_| |_| |_|\___| \_/\_/ \___/|_|  |_|\_\
                                                                               
===================================================================================

API docs: https://docs.nanoframework.net/api/nanoFramework.Sytem.Net.Http.html

Browse our samples repository: https://github.com/nanoframework/samples

Check our documentation online: https://docs.nanoframework.net/

Join our lively Discord community: https://discord.gg/gCyBu8T

Report issues: https://github.com/nanoframework/Home/issues

Follow us on Twitter: https://twitter.com/nanoframework

Follow our YouTube channel: https://www.youtube.com/c/nanoFramework
