using System;
using System.Diagnostics;
using System.Threading;
using System.Text;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using System.Net.NetworkInformation;
using System.Security.Cryptography.X509Certificates;

using System.Net;
using System.Net.Sockets;
using System.Net.NetworkInformation;

namespace NFMQTT
{
    public class Program
    {
   
          private const string c_SSID = "valoninet";
        private const string c_AP_PASSWORD = "valoni1234567";

        public static void Main()
        {
            MqttClient client = null;
            string clientId;
            bool running = true;

            X509Certificate caCert = new X509Certificate(VGetCertificate);
            X509Certificate clCert = new X509Certificate(VGetClCertificate); 

            // Wait for network to connect (temp)
            SetupAndConnectNetwork();
            Thread.Sleep(300);

            DateTime dateTime = GetNetworkTime(2);
            nanoFramework.Runtime.Native.Rtc.SetSystemTime(dateTime);

            Debug.WriteLine(dateTime.ToString("yyyy.MM.dd HH:mm:ss.fff"));

            //SetDateTime();
            Thread.Sleep(300);
            Debug.WriteLine(DateTime.UtcNow.ToString("yyyy.MM.dd HH:mm:ss.fff"));

            // connect to the Mosquito test server
            client = new MqttClient("val.itdbcks.net", 8883, true, caCert, clCert, MqttSslProtocols.TLSv1_2);
            //client = new MqttClient("test.mosquitto.org", 8883, true, caCert, clCert, MqttSslProtocols.TLSv1_2);
            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString().Substring(0,16).ToString();
            
            Debug.WriteLine("Connecting to Mosquito test server...");

            client.Connect(clientId,"Valon","Test");
            //client.Connect(clientId);
            Debug.WriteLine("Connected to Mosquito test server");

            while (running)
            {
                // send random temperature value to Gauge demo in Mosquito test server, see http://test.mosquitto.org/gauge/
                client.Publish("home/temperature", GetRandomTemperature(), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false);
                Thread.Sleep(200);
                client.Publish("home/humidity", GetRandomHumidity(), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false);

                // the Mosquito test server has a local process that updates every 15 seconds, so we just follow that
                Thread.Sleep(5000);
            }

            client.Disconnect();

            // prevent app from returning, ever
            Thread.Sleep(Timeout.Infinite);
        }

        private static byte[] GetRandomTemperature()
        {
            // generate random value
            Random randomProvider = new Random();
            var randomTemperature = randomProvider.NextDouble() * 10;

            // convert to string formatted NN.NN
            var temperatureAsString = randomTemperature.ToString("N2");

            Debug.WriteLine($"Temperature: {temperatureAsString}");

            return Encoding.UTF8.GetBytes(temperatureAsString);
        }

        private static byte[] GetRandomHumidity()
        {
            // generate random value
            Random randomProvider = new Random();
            var randomHumidity = randomProvider.NextDouble() * 90;

            // convert to string formatted NN.NN
            var humidityAsString = randomHumidity.ToString("N2");

            Debug.WriteLine($"Humidity: {humidityAsString}");

            return Encoding.UTF8.GetBytes(humidityAsString);
        }

        /* compatible with .NET Microframework and nanoFramework too        
          https://stackoverflow.com/questions/1193955/how-to-query-an-ntp-server-using-c      
          */
        public static DateTime GetNetworkTime(int CorrectLocalTime = 0)
        {
            const string ntpServer = "pool.ntp.org";
            var ntpData = new byte[48];
            ntpData[0] = 0x1B; //LeapIndicator = 0 (no warning), VersionNum = 3 (IPv4 only), Mode = 3 (Client Mode)

            var addresses = Dns.GetHostEntry(ntpServer).AddressList;
            var ipEndPoint = new IPEndPoint(addresses[0], 123);
            var socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            socket.Connect(ipEndPoint);

            Thread.Sleep(1); // added to support TinyCLR OS too

            socket.Send(ntpData);
            socket.Receive(ntpData);
            socket.Close();

            ulong intPart = (ulong)ntpData[40] << 24 | (ulong)ntpData[41] << 16 | (ulong)ntpData[42] << 8 | (ulong)ntpData[43];
            ulong fractPart = (ulong)ntpData[44] << 24 | (ulong)ntpData[45] << 16 | (ulong)ntpData[46] << 8 | (ulong)ntpData[47];

            var milliseconds = (intPart * 1000) + ((fractPart * 1000) / 0x100000000L);
            var networkDateTime = (new DateTime(1900, 1, 1)).AddMilliseconds((long)milliseconds);

            return networkDateTime.AddHours(CorrectLocalTime);
        }

        public static void SetupAndConnectNetwork()
        {
            NetworkInterface[] nis = NetworkInterface.GetAllNetworkInterfaces();
            if (nis.Length > 0)
            {
                // get the first interface
                NetworkInterface ni = nis[0];

                if (ni.NetworkInterfaceType == NetworkInterfaceType.Wireless80211)
                {
                    // network interface is Wi-Fi
                    Debug.WriteLine("Network connection is: Wi-Fi");

                    Wireless80211Configuration wc = Wireless80211Configuration.GetAllWireless80211Configurations()[ni.SpecificConfigId];
                    if (wc.Ssid != c_SSID && wc.Password != c_AP_PASSWORD)
                    {
                        // have to update Wi-Fi configuration
                        wc.Ssid = c_SSID;
                        wc.Password = c_AP_PASSWORD;
                        wc.SaveConfiguration();
                    }
                    else
                    {   // Wi-Fi configuration matches
                    }
                }
                else
                {
                    // network interface is Ethernet
                    Debug.WriteLine("Network connection is: Ethernet");

                    ni.EnableDhcp();
                }

                // wait for DHCP to complete
                WaitIP();
            }
            else
            {
                throw new NotSupportedException("ERROR: there is no network interface configured.\r\nOpen the 'Edit Network Configuration' in Device Explorer and configure one.");
            }
        }

        static void WaitIP()
        {
            Debug.WriteLine("Waiting for IP...");

            while (true)
            {
                NetworkInterface ni = NetworkInterface.GetAllNetworkInterfaces()[0];
                if (ni.IPv4Address != null && ni.IPv4Address.Length > 0)
                {
                    if (ni.IPv4Address[0] != '0')
                    {
                        Debug.WriteLine($"We have an IP: {ni.IPv4Address}");
                        break;
                    }
                }

                Thread.Sleep(500);
            }
        }

        private static void SetDateTime()
        {
            Debug.WriteLine("Setting up system clock...");
            Debug.WriteLine(DateTime.UtcNow.ToString("yyyy.MM.dd HH:mm:ss.fff"));
            // set system date time (needs to be accurate to the day in order to be able to validate a certificate)
            //Rtc.SetSystemTime(new DateTime(2018, 08, 02));

            // if SNTP is available and enabled on target device this can be skipped because we should have a valid date & time
            while (DateTime.UtcNow.Year < 2018)
            {
                Debug.WriteLine("Waiting for valid date time...");
                // wait for valid date & time
                Thread.Sleep(1000);
                
            }
        }

        // Mosquito test server CA certificate
        // from http://val.itdbcks.net

        // X509 
        static string VGetCertificate =
@"-----BEGIN CERTIFICATE-----
MIIDHTCCAgWgAwIBAgIUR4nFISPQlCg0mLklY5EncQRtSPkwDQYJKoZIhvcNAQEL
BQAwHjELMAkGA1UEBhMCWEsxDzANBgNVBAMMBlZNSC1DQTAeFw0yMDA5MDIxMjIw
MTJaFw0zMDA4MzExMjIwMTJaMB4xCzAJBgNVBAYTAlhLMQ8wDQYDVQQDDAZWTUgt
Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDG73m/Qr81frs7GosP
M73qdN2QiyRIRK8F+InX3utZJ31swR0nn2R2BreQ2yhCuviUP/084TB/nQ2Ah/A5
/VzCNecGgOM31Je/9Km+v6KO1l1l22pczLHcpUh2ZpcHLnwyjEXpoLCi6uKnkYwl
WuJCpjYkwli1jtMutjBiMfJRAneMhf0rFYM5qxlQMy2l/r9Vwd/PpMBWLeb90Hd3
GsobsnSGnVhjj1OwoFn2BRUGKkG57qBDPKm1M3MkyklZsc4MJpDEqbzQslhDkQoo
Q87COutqkLgY61W2dAbQ0LpyerwAjNRimfd5kVSg6xe4XzCaVNJ/Tm319KMrxLs2
Iw8fAgMBAAGjUzBRMB0GA1UdDgQWBBT8pfHf997WUfvdxJhRoyuJrolUBzAfBgNV
HSMEGDAWgBT8pfHf997WUfvdxJhRoyuJrolUBzAPBgNVHRMBAf8EBTADAQH/MA0G
CSqGSIb3DQEBCwUAA4IBAQAJ51ekYwAzMB50izpoDZr39cEMqBeCii4lfAVpHvpw
fm82JgwdtaHfcF5B+5lqY3NCKUHBYBk+EHGT8dDLxirCXSA7brslr3SL4aaZ9BrU
Y0ZA4Czk0FrrLDCawBrKZ2fymZ6n+LkkwEVkUpOM3sxVW1KTTt8Tk+cD3nDqBV2R
0RCfiH+MffmgmzGsV2aKrzPJdltGOCgEW9ErsrUbTziTJ4U+yFAvZxZPQAaML2Xf
MvBRE5HHA0MpH93xyhAFQ811gGcJkmwQA8lEoX11gIV4PCssj4mbB7IQYnvK0UWZ
WsEB4WPdj/Kp25IthQz5tERqei50Km5bLDZrXQqPuE++
-----END CERTIFICATE-----";


        static string VGetClCertificate =
@"-----BEGIN CERTIFICATE-----
MIIDmDCCAoCgAwIBAgIUMRiW7q1lCSYkKiL6lxwlTnZ7zBQwDQYJKoZIhvcNAQEL
BQAwHjELMAkGA1UEBhMCWEsxDzANBgNVBAMMBlZNSC1DQTAeFw0yMDA5MDQwNTU0
NDNaFw0yODEyMTUwNTU0NDNaMFUxCzAJBgNVBAYTAlhLMQswCQYDVQQIDAJYSzES
MBAGA1UEBwwJUHJpc2h0aW5hMQswCQYDVQQKDAJWSDEYMBYGA1UEAwwPdmFsLml0
ZGJja3MubmV0MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA633l77dp
9aNm4gB8ftdkJ28jwH1GZ0s4toQYAV81R5maM9OIF8r3uQoaRurJWjK2pdKNvhbk
IQdbzWZAKewtVhythLs5+rjSACXgIDiiHOc63+c6Mv8pXmrIca4y7XkBEIVKvhrM
QpDPqzlmpd3SEmXmv4l3ogM1keckBNmXefCWuRWztoPqHXBV93GgexJMOFQJxjxL
oL45nW8yNpvDyIHylKE2tAYP6cnin2WF6RTAZUNYlQZZdUwcXg0kXcoKvl2zADW/
FbtazeOdNI79FSduQiivzwqKhf6TS8b9f+2LDDgXrqb/EBz7zmxv8w6bG7+NO9jG
xUziMctsi96qOQIDAQABo4GWMIGTMB8GA1UdIwQYMBaAFPyl8d/33tZR+93EmFGj
K4muiVQHMAkGA1UdEwQCMAAwCwYDVR0PBAQDAgTwMFgGA1UdEQRRME+CD3ZhbC5p
dGRiY2tzLm5ldIIPdmFsb25pLmRkbnMubmV0gglsb2NhbGhvc3SCDTE5Mi4xNjgu
Mi4xMTCCBm1lcml0YYIJMTI3LjAuMC4xMA0GCSqGSIb3DQEBCwUAA4IBAQAph82r
TXSpDEakU3IytuXInaiow9RvKp5nR0W4/WR8cD1eOaYcDypXktM+xh9uSE+KahMM
/khVUUSoK9X9ZqGoOBRmR4ij+hPrQjm9NkCq8U9vadcOgwwlo79GHN/inkzLBU00
E7hfqBjUxvXI7Zpv/4LejoHWazq517nU8C9KvgB/p7a2XNQaBXaf6HrFQ2Mds1oZ
RZaXlb0hxiDkYex1JtvL6w0fE1efhzYdC1a1LlRLeRKpUaaISognlhYLHmU0zoEJ
IGSs6OYZAbIZa/xpRBfySEIXcK3n2MFCh3RsWCxWXB1fnXyzdCIapFOTw2LNBmik
MhNkOLiEBVHPUI8Z
-----END CERTIFICATE-----";

        static string MGetCertificate =
@"-----BEGIN CERTIFICATE-----
MIIEAzCCAuugAwIBAgIUBY1hlCGvdj4NhBXkZ/uLUZNILAwwDQYJKoZIhvcNAQEL
BQAwgZAxCzAJBgNVBAYTAkdCMRcwFQYDVQQIDA5Vbml0ZWQgS2luZ2RvbTEOMAwG
A1UEBwwFRGVyYnkxEjAQBgNVBAoMCU1vc3F1aXR0bzELMAkGA1UECwwCQ0ExFjAU
BgNVBAMMDW1vc3F1aXR0by5vcmcxHzAdBgkqhkiG9w0BCQEWEHJvZ2VyQGF0Y2hv
by5vcmcwHhcNMjAwNjA5MTEwNjM5WhcNMzAwNjA3MTEwNjM5WjCBkDELMAkGA1UE
BhMCR0IxFzAVBgNVBAgMDlVuaXRlZCBLaW5nZG9tMQ4wDAYDVQQHDAVEZXJieTES
MBAGA1UECgwJTW9zcXVpdHRvMQswCQYDVQQLDAJDQTEWMBQGA1UEAwwNbW9zcXVp
dHRvLm9yZzEfMB0GCSqGSIb3DQEJARYQcm9nZXJAYXRjaG9vLm9yZzCCASIwDQYJ
KoZIhvcNAQEBBQADggEPADCCAQoCggEBAME0HKmIzfTOwkKLT3THHe+ObdizamPg
UZmD64Tf3zJdNeYGYn4CEXbyP6fy3tWc8S2boW6dzrH8SdFf9uo320GJA9B7U1FW
Te3xda/Lm3JFfaHjkWw7jBwcauQZjpGINHapHRlpiCZsquAthOgxW9SgDgYlGzEA
s06pkEFiMw+qDfLo/sxFKB6vQlFekMeCymjLCbNwPJyqyhFmPWwio/PDMruBTzPH
3cioBnrJWKXc3OjXdLGFJOfj7pP0j/dr2LH72eSvv3PQQFl90CZPFhrCUcRHSSxo
E6yjGOdnz7f6PveLIB574kQORwt8ePn0yidrTC1ictikED3nHYhMUOUCAwEAAaNT
MFEwHQYDVR0OBBYEFPVV6xBUFPiGKDyo5V3+Hbh4N9YSMB8GA1UdIwQYMBaAFPVV
6xBUFPiGKDyo5V3+Hbh4N9YSMA8GA1UdEwEB/wQFMAMBAf8wDQYJKoZIhvcNAQEL
BQADggEBAGa9kS21N70ThM6/Hj9D7mbVxKLBjVWe2TPsGfbl3rEDfZ+OKRZ2j6AC
6r7jb4TZO3dzF2p6dgbrlU71Y/4K0TdzIjRj3cQ3KSm41JvUQ0hZ/c04iGDg/xWf
+pp58nfPAYwuerruPNWmlStWAXf0UTqRtg4hQDWBuUFDJTuWuuBvEXudz74eh/wK
sMwfu1HFvjy5Z0iMDU8PUDepjVolOCue9ashlS4EB5IECdSR2TItnAIiIwimx839
LdUdRudafMu5T5Xma182OC0/u/xRlEm+tvKGGmfFcN0piqVl8OrSPBgIlb+1IKJE
m/XriWr/Cq4h/JfB7NTsezVslgkBaoU=
-----END CERTIFICATE-----";

        static string MGetClCertificate =
@"-----BEGIN CERTIFICATE-----
MIIDsDCCApigAwIBAgIBADANBgkqhkiG9w0BAQsFADCBkDELMAkGA1UEBhMCR0Ix
FzAVBgNVBAgMDlVuaXRlZCBLaW5nZG9tMQ4wDAYDVQQHDAVEZXJieTESMBAGA1UE
CgwJTW9zcXVpdHRvMQswCQYDVQQLDAJDQTEWMBQGA1UEAwwNbW9zcXVpdHRvLm9y
ZzEfMB0GCSqGSIb3DQEJARYQcm9nZXJAYXRjaG9vLm9yZzAeFw0yMDA5MDYwODU0
MDNaFw0yMDEyMDUwODU0MDNaMIGJMQswCQYDVQQGEwJYSzELMAkGA1UECAwCWEsx
EjAQBgNVBAcMCVByaXNodGluYTELMAkGA1UECgwCWEsxCzAJBgNVBAsMAlhLMRgw
FgYDVQQDDA92YWwuaXRkYmNrcy5uZXQxJTAjBgkqhkiG9w0BCQEWFnZhbG9uLmhv
dGlAaXRkYmNrcy5uZXQwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDl
WZWcLTRIrVmghjrnHKS77INwfroTYxceotfGJuQ6oKozSO+UMuojlJJnBuDUejJS
vYwjmaB2lvxjBYX/jH7GHvcZoff/ZdyRacykWkxJTzsTpc01Pit1oei6O3fIxFVC
pvXwLGbPnDM8Oj91VrCQcmvqb3aYHLRM87ozQaDDH/6/88xPIK5gFCSLlepSs1dT
D7s/oat4IeShtYoxuwkaj3jhFLxoqnE8rE8MJHMAqNFXeRZTEk2phWqlbF+DRJe0
q7Qb6xKWoyRZjGSWKHRmSzhbUgpf1a+sJqmv/r2lQqsVdQShzn6Nxj+QTMdKpnVg
Q5lK2men8DJwkS43xBhfAgMBAAGjGjAYMAkGA1UdEwQCMAAwCwYDVR0PBAQDAgXg
MA0GCSqGSIb3DQEBCwUAA4IBAQA/DrSEyWHM/gnvz7Cwv3WoQZUVJQOQimJYyC9U
o8YnDVrzhGepo5wIko2MMsgD2j7MDuQ9Jdw14wKa8W0brDqsFfZI1QARc6bzftDH
FOCV5d+YQqVWruZv4HY88bTDeM0KUvvk87+L8R+jiyHEOM6/cpDnloPZTvkRrUC7
SW/ujEP9T0tScW+EX/dcWgNI8g0HBP/lG/KS9ZgWB+GGrcpd/GiPylVUMW8UUl40
newBV5ThOELdMMPQi5JaT+PmrsIyoX3mUW2teGryyaPmTLURy2FasEUbhbJt3F7D
7+I5LVtyHlJgnIFrR/J6IvUZT4n3vU+4hrDF+TQhgZNNH10I
-----END CERTIFICATE-----";

    }
}
