﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Net;
using System.Net.NetworkInformation;

using uPLibrary.Networking;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using uPLibrary.Networking.M2Mqtt.Utility;
using uPLibrary.Networking.M2Mqtt.Session;

using System.IO;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Threading;

namespace MQTTm2m
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            string clientId = this.textBox1.Text;
            var MQTT_BROKER_ADDRESS = this.textBox2.Text;
            var brokerport = Convert.ToInt32(this.textBox3.Text);

            var caCertificate = new X509Certificate2(this.textBox6.Text);
            MqttClient client = new MqttClient(MQTT_BROKER_ADDRESS, brokerport, true, caCertificate, null, MqttSslProtocols.TLSv1_2);

            //var clCertificate = new X509Certificate2(this.textBox7.Text,"a",X509KeyStorageFlags.Exportable);
            //MqttClient client = new MqttClient(MQTT_BROKER_ADDRESS,8883,true, caCertificate, clCertificate, MqttSslProtocols.TLSv1_2);


            //string clientId = Guid.NewGuid().ToString();
        

            client.Connect(clientId, this.textBox4.Text , this.textBox5.Text);

            while (true)
            {
                Random random = new Random();
                string strValue = random.Next(10, 40).ToString();
                string strValue2 = random.Next(0, 100).ToString();

                this.textBox8.Text += DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss.fff") + "/temp ->>" + strValue + Environment.NewLine;
                this.textBox8.Text += DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss.fff") + "/hume ->>" + strValue2 + Environment.NewLine;
                this.textBox8.Refresh();

                // publish a message on "/home/temperature" topic with QoS 2 
                client.Publish("home/temperature", Encoding.UTF8.GetBytes(strValue), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);
                client.Publish("home/humidity", Encoding.UTF8.GetBytes(strValue2), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);

                Thread.Sleep(5000);
            }
        }
    }
}
